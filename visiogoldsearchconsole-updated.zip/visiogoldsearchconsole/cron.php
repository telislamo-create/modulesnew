<?php
$root = dirname(__DIR__, 2);
require_once $root . '/config/config.inc.php';
require_once $root . '/init.php';
header('Content-Type: application/json; charset=utf-8');
$module = Module::getInstanceByName('visiogoldsearchconsole');
$token = (string) Tools::getValue('token');
$expected = $module ? (string) Configuration::get('VGSC_AI_CRON_TOKEN') : '';
if (!$module || $expected === '' || !function_exists('hash_equals') || !hash_equals($expected, $token)) {
    http_response_code(403);
    die(Tools::jsonEncode(array('ok' => false, 'error' => 'Invalid cron token.')));
}
if (!(int) Configuration::get('VGSC_AI_CRON_ENABLED')) {
    die(Tools::jsonEncode(array('ok' => false, 'error' => 'AI cron is disabled.')));
}
$result = $module->runAiQueueStep();
echo Tools::jsonEncode(array('ok' => true, 'pending' => !empty($result['pending']), 'message' => $result['message']));
