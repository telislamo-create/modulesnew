
## SEO Autopilot Workflow (v1.5.1)

The module now includes an opt-in Back Office tab named **SEO Autopilot**. Upload a Search Console CSV containing `Query`, `Page`, `Position`, `CTR`, and optionally `Impressions`. CTR values may be supplied as percentages (`1.80%`) or decimal fractions (`0.018`). The import also serves as the performance re-check after 14 or 30 days.

The safety classifier is deliberately conservative:

- **PROTECTED / Do Not Touch:** position <= 3 **or** CTR > 5%. These rows are never exposed as editable opportunities and are rejected again server-side if their metrics change before apply.
- **OPPORTUNITY:** position 4–20 and CTR < 2%. Only these rows receive an editor/proposal action.
- All other rows are retained as `other` and are not modified.

The editor shows current meta title, meta description, and excerpt beside a constrained proposal. The server enforces a maximum 60-character title ending in `- VisionGold`, a maximum 155-character description, and rejects `CAD`, `3D`, `Seal`, and `Chevron`. The proposal copy emphasizes Signet/Signet RING/Chevalier where appropriate, handmade construction, and 925 silver/gold.

Installation creates `ps_visiongold_seo_log` (the actual prefix follows the shop's `_DB_PREFIX_`) and `ps_visiongold_gsc_row`. The log stores the complete before/after values, Search Console baseline, latest re-check, status, shop, language, and target URL. Performance is green when CTR increases or average position improves; otherwise it is marked stagnant. Rollback restores the original multilingual product/category fields in one click and marks the log `reverted`.

The workflow is implemented in `visiogoldsearchconsole.php`, `views/templates/admin/configure.tpl`, and `views/css/admin.css`; the tables are created automatically by the module install/upgrade path. Test on a staging copy first, verify the shop's URL rewrite and language setup, and take a database backup before applying SEO changes. The delivery environment does not include the PHP CLI, so syntax validation was performed by static delimiter/structure checks and ZIP integrity testing; run `php -l` and install-test in the target PrestaShop environment before production use.

## Hardening in v1.6.0

Large sitemap requests now use an index only when the `part` parameter is absent, so explicit `part=0` serves the first 50,000 URLs. Products with `visibility=none` are excluded. Back Office 404/AI data is loaded only for the active tab. 404 logging deduplicates identical URLs for one hour, caps burst logging at 100 entries per IP in five minutes, and performs retention purge occasionally during traffic instead of depending only on an admin visit. AI provider calls have shorter connect/request timeouts and reserve headroom before starting another request.
