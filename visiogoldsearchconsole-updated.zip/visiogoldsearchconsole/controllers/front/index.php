<?php
// Silence is golden.
