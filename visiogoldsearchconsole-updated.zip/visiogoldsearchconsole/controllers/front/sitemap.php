<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

class VisioGoldSearchConsoleSitemapModuleFrontController extends ModuleFrontController
{
    const MAX_URLS = 50000;

    public function initContent()
    {
        parent::initContent();
        if (!(int) Configuration::get('VGSC_SITEMAP')) {
            header('HTTP/1.1 404 Not Found');
            exit;
        }
        $union = $this->getUnionSql();
        $total = (int) Db::getInstance()->getValue('SELECT COUNT(*) FROM (' . $union . ') AS sitemap_items');
        $hasPart = Tools::getIsset('part');
        $part = max(0, (int) Tools::getValue('part', 0));
        $parts = max(1, (int) ceil($total / self::MAX_URLS));
        header('Content-Type: application/xml; charset=utf-8');
        header('X-Robots-Tag: noindex');
        if (!$hasPart && $parts > 1) {
            echo $this->renderIndex($parts);
            exit;
        }
        if ($part > $parts) {
            header('HTTP/1.1 404 Not Found');
            exit;
        }
        echo $this->renderUrlSet($union, $part * self::MAX_URLS, self::MAX_URLS);
        exit;
    }

    private function getUnionSql()
    {
        $shop = (int) $this->context->shop->id;
        $sql = array();
        $sql[] = "SELECT 'product' AS kind, ps.id_product AS object_id, pl.id_lang AS id_lang FROM " . _DB_PREFIX_ . "product_shop ps INNER JOIN " . _DB_PREFIX_ . "product_lang pl ON pl.id_product=ps.id_product AND pl.id_shop=ps.id_shop WHERE ps.id_shop=" . $shop . " AND ps.active=1 AND ps.visibility <> 'none' AND pl.link_rewrite IS NOT NULL AND pl.link_rewrite<>'' AND EXISTS (SELECT 1 FROM " . _DB_PREFIX_ . "lang l WHERE l.id_lang=pl.id_lang AND l.active=1)";
        $sql[] = "SELECT 'category' AS kind, cs.id_category AS object_id, cl.id_lang AS id_lang FROM " . _DB_PREFIX_ . "category_shop cs INNER JOIN " . _DB_PREFIX_ . "category c ON c.id_category=cs.id_category INNER JOIN " . _DB_PREFIX_ . "category_lang cl ON cl.id_category=c.id_category AND cl.id_shop=cs.id_shop WHERE cs.id_shop=" . $shop . " AND c.active=1 AND c.id_category>2 AND cl.link_rewrite IS NOT NULL AND cl.link_rewrite<>'' AND EXISTS (SELECT 1 FROM " . _DB_PREFIX_ . "lang l WHERE l.id_lang=cl.id_lang AND l.active=1)";
        $sql[] = "SELECT 'cms' AS kind, cms.id_cms AS object_id, cl.id_lang AS id_lang FROM " . _DB_PREFIX_ . "cms cms INNER JOIN " . _DB_PREFIX_ . "cms_shop cs ON cs.id_cms=cms.id_cms AND cs.id_shop=" . $shop . " INNER JOIN " . _DB_PREFIX_ . "cms_lang cl ON cl.id_cms=cms.id_cms AND cl.id_shop=cs.id_shop WHERE cms.active=1 AND cl.link_rewrite IS NOT NULL AND cl.link_rewrite<>'' AND EXISTS (SELECT 1 FROM " . _DB_PREFIX_ . "lang l WHERE l.id_lang=cl.id_lang AND l.active=1)";
        return implode(' UNION ALL ', $sql);
    }

    private function renderIndex($parts)
    {
        $xml = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
        $xml .= '<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";
        for ($part = 0; $part < $parts; $part++) {
            $url = $this->context->link->getModuleLink($this->module->name, 'sitemap', array('part' => $part), true);
            $xml .= '<sitemap><loc>' . $this->xml($url) . '</loc></sitemap>' . "\n";
        }
        return $xml . '</sitemapindex>';
    }

    private function renderUrlSet($union, $offset, $limit)
    {
        $rows = Db::getInstance()->executeS('SELECT * FROM (' . $union . ') AS sitemap_items ORDER BY kind, object_id, id_lang LIMIT ' . (int) $offset . ', ' . (int) $limit);
        $xml = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
        $xml .= '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:xhtml="http://www.w3.org/1999/xhtml">' . "\n";
        if (is_array($rows)) {
            foreach ($rows as $row) {
                $url = $this->getEntityUrl($row);
                if (!$url) {
                    continue;
                }
                $xml .= '<url><loc>' . $this->xml($url) . '</loc>';
                $alternates = $this->getAlternates($row);
                foreach ($alternates as $alternate) {
                    $xml .= '<xhtml:link rel="alternate" hreflang="' . $this->xml($alternate['hreflang']) . '" href="' . $this->xml($alternate['url']) . '" />';
                }
                $xml .= '</url>' . "\n";
            }
        }
        return $xml . '</urlset>';
    }

    private function getEntityUrl($row)
    {
        $id = (int) $row['object_id'];
        $idLang = (int) $row['id_lang'];
        try {
            if ($row['kind'] === 'product') {
                $object = new Product($id, false, $idLang, (int) $this->context->shop->id);
                if (!Validate::isLoadedObject($object) || !(int) $object->active || empty($object->link_rewrite)) {
                    return '';
                }
                return $this->context->link->getProductLink($object, null, null, null, $idLang);
            }
            if ($row['kind'] === 'category') {
                $object = new Category($id, $idLang, (int) $this->context->shop->id);
                if (!Validate::isLoadedObject($object) || !(int) $object->active || empty($object->link_rewrite)) {
                    return '';
                }
                return $this->context->link->getCategoryLink($object, null, $idLang);
            }
            $cms = new CMS($id, $idLang, (int) $this->context->shop->id);
            if (!Validate::isLoadedObject($cms) || !(int) $cms->active || empty($cms->link_rewrite)) {
                return '';
            }
            return $this->context->link->getCMSLink($cms, null, null, $idLang);
        } catch (Exception $e) {
            return '';
        }
    }

    private function getAlternates($row)
    {
        $alternates = array();
        $id = (int) $row['object_id'];
        $kind = $row['kind'];
        $languages = Language::getLanguages(true, (int) $this->context->shop->id);
        foreach ($languages as $language) {
            $langId = (int) $language['id_lang'];
            if ($kind === 'product') {
                $object = new Product($id, false, $langId, (int) $this->context->shop->id);
                if (!Validate::isLoadedObject($object) || !(int) $object->active || empty($object->link_rewrite)) {
                    continue;
                }
                $url = $this->context->link->getProductLink($object, null, null, null, $langId);
            } elseif ($kind === 'category') {
                $object = new Category($id, $langId, (int) $this->context->shop->id);
                if (!Validate::isLoadedObject($object) || !(int) $object->active || empty($object->link_rewrite)) {
                    continue;
                }
                $url = $this->context->link->getCategoryLink($object, null, $langId);
            } else {
                $object = new CMS($id, $langId, (int) $this->context->shop->id);
                if (!Validate::isLoadedObject($object) || !(int) $object->active || empty($object->link_rewrite)) {
                    continue;
                }
                $url = $this->context->link->getCMSLink($object, null, null, $langId);
            }
            $code = !empty($language['locale']) ? str_replace('_', '-', $language['locale']) : $language['iso_code'];
            $alternates[] = array('hreflang' => $code, 'url' => $url);
        }
        return $alternates;
    }

    private function xml($value)
    {
        return htmlspecialchars((string) $value, ENT_XML1 | ENT_COMPAT, 'UTF-8');
    }
}
