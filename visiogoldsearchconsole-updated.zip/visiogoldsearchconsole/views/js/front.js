(function () {
  'use strict';
  function optimizeImages() {
    var productMain = document.querySelector('.product-cover img, .js-qv-product-cover, #bigpic, .product-page .product-image img');
    if (productMain) {
      productMain.setAttribute('fetchpriority', 'high');
      productMain.setAttribute('loading', 'eager');
      productMain.setAttribute('decoding', 'async');
    }
    var images = document.querySelectorAll('img');
    for (var i = 0; i < images.length; i++) {
      var image = images[i];
      if (image === productMain) continue;
      if (image.hasAttribute('data-no-lazy') || image.closest('[data-no-lazy="true"]')) continue;
      if (image.getAttribute('loading') !== 'eager') image.setAttribute('loading', 'lazy');
      if (!image.hasAttribute('decoding')) image.setAttribute('decoding', 'async');
    }
  }
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', optimizeImages, { once: true });
  } else {
    optimizeImages();
  }
  if (window.MutationObserver && document.documentElement) {
    var observer = new MutationObserver(function (mutations) {
      for (var m = 0; m < mutations.length; m++) {
        for (var n = 0; n < mutations[m].addedNodes.length; n++) {
          var node = mutations[m].addedNodes[n];
          if (node.nodeType === 1 && (node.tagName === 'IMG' || (node.querySelector && node.querySelector('img')))) {
            optimizeImages();
            return;
          }
        }
      }
    });
    observer.observe(document.documentElement, { childList: true, subtree: true });
  }
}());
