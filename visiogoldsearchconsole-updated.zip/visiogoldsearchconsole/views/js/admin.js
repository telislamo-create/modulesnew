(function () {
  'use strict';

  function openHelp(title, text) {
    var overlay = document.createElement('div');
    overlay.className = 'vgsc-help-overlay';
    overlay.setAttribute('role', 'dialog');
    overlay.setAttribute('aria-modal', 'true');
    overlay.innerHTML = '<div class="vgsc-help-dialog"><button type="button" class="vgsc-help-close" aria-label="Κλείσιμο">×</button><div class="vgsc-help-dialog-icon">?</div><h2></h2><p></p><button type="button" class="btn btn-primary vgsc-help-ok">Κατάλαβα</button></div>';
    overlay.querySelector('h2').textContent = title || 'Βοήθεια';
    overlay.querySelector('p').textContent = text || 'Δεν υπάρχει διαθέσιμη επεξήγηση.';
    document.body.appendChild(overlay);
    var close = function () { overlay.remove(); };
    overlay.querySelector('.vgsc-help-close').addEventListener('click', close);
    overlay.querySelector('.vgsc-help-ok').addEventListener('click', close);
    overlay.addEventListener('click', function (event) { if (event.target === overlay) close(); });
    document.addEventListener('keydown', function esc(event) { if (event.key === 'Escape') { close(); document.removeEventListener('keydown', esc); } });
    overlay.querySelector('.vgsc-help-ok').focus();
  }

  function addSettingsHelp() {
    document.querySelectorAll('.ultseo-toggle-row').forEach(function (row) {
      if (row.querySelector('.vgsc-help-mark')) return;
      var title = row.querySelector('b');
      var description = row.querySelector('small');
      if (!title || !description) return;
      var help = document.createElement('span');
      help.className = 'vgsc-help-mark';
      help.setAttribute('role', 'button');
      help.setAttribute('tabindex', '0');
      help.setAttribute('data-help-title', title.textContent.trim());
      help.setAttribute('data-help', description.textContent.trim());
      help.textContent = '?';
      row.appendChild(help);
    });
  }

  document.addEventListener('click', function (event) {
    var icon = event.target.closest('.vgsc-nav-help, .vgsc-help-mark');
    if (!icon) return;
    var owner = icon.closest('[data-help]') || icon;
    event.preventDefault();
    event.stopPropagation();
    openHelp(owner.getAttribute('data-help-title'), owner.getAttribute('data-help'));
  }, true);
  document.addEventListener('keydown', function (event) {
    if ((event.key === 'Enter' || event.key === ' ') && event.target.matches('.vgsc-help-mark')) {
      event.preventDefault();
      event.target.click();
    }
  });
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', addSettingsHelp, { once: true });
  else addSettingsHelp();
}());
